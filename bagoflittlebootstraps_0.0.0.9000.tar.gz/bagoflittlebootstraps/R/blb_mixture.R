#' Function for BLB in gaussian mixture models
#'
#' Implements the BLB algorithm in GMMs
#' 
#' @param Y numeric vector of data 
#' @param b numeric input for the subset size
#' @param s numeric input for the number of sampled subsets
#' @param r numeric input for the number of Monte Carlo iterations
#' @param d numeric input for the number of mixture components
#' 
#' @keywords Gaussian mixture models
#' 
#' @return 95% confidence intervals of the estimates of mu, sigma and p 
#' 
#' @export

blb_mixture <- function(Y, b , s, r, d){
  n = length(Y)
  
  mean_lower = mean_upper = matrix(NA, nrow = s, ncol = d)
  sd_lower = sd_upper = matrix(NA, nrow = s, ncol = d)
  p_lower = p_upper = matrix(NA, nrow = s, ncol = d)
  
  
  # Subsample the data
  for(j in 1:s){
    # Get a subsample
    subsample = sample(1:n, b, replace = FALSE)
    Ysub = Y[subsample]
    
    fit_p = matrix(NA, nrow = r, ncol = d) 
    fit_mean = matrix(NA, nrow = r, ncol = d) 
    fit_sd = matrix(NA, nrow = r, ncol = d) 
    
    # Approximate assessment of estimator
    for(k in 1:r){
      multisamp = sample(1:b, n, replace = TRUE)
      fit = Mclust(Ysub[multisamp], G = d, verbose=FALSE)
      fit_p[k,] = fit$parameters$pro
      fit_mean[k,] = fit$parameters$mean
      if(length(fit$parameters$variance$sigmasq)==1){
        fit_sd[k,] = rep(sqrt(fit$parameters$variance$sigmasq), d)
      } else{
        fit_sd[k,] = sqrt(fit$parameters$variance$sigmasq)
      }
    }
    
    mean_lower[j,]  = apply(fit_mean, 2, function(x) quantile(x, .025))
    mean_upper[j,]  = apply(fit_mean, 2, function(x) quantile(x, .975))
    sd_lower[j,]    = apply(fit_sd,   2, function(x) quantile(x, .025))
    sd_upper[j,]    = apply(fit_sd,   2, function(x) quantile(x, .975))
    p_lower[j,]     = apply(fit_p,    2, function(x) quantile(x, .025))
    p_upper[j,]     = apply(fit_p,    2, function(x) quantile(x, .975))
  }
  return(list(
    lower_mean = colMeans(mean_lower), 
    upper_mean = colMeans(mean_upper),
    lower_sd = colMeans(sd_lower), 
    upper_sd = colMeans(sd_upper),
    lower_p = colMeans(p_lower), 
    upper_p = colMeans(p_upper)
  )
  )
}
